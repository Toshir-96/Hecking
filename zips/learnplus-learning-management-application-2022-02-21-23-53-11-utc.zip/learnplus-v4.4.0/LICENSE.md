# License

> Licensing is EXCLUSIVELY available for purchase via [ThemeForest](http://themeforest.net) on [Envato Market](http://market.envato.com). To see all the available licenses and details, see [http://themeforest.net/licenses](http://themeforest.net/licenses). You can also [puchase a license right now](#)

---

### Why purchase a license?

- We're giving a lot of time, effort and dedication into creating and maintaining our premium items, with a primary focus to make your life easier as a developer and entrepreneur.
- Show us your appreciation and support our efforts, in order to support yourself.
- Get help and receive tech support directly from our team.
- Get bug fixes and future updates.
- Ever heard of KARMA? ;)