import Vue from 'vue'
import AppSettings from './app-settings.vue'

new Vue({
  el: '#app-settings',
  components: {
    AppSettings
  }
})
