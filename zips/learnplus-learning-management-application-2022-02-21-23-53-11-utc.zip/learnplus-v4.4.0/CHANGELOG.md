## LearnPlus v4.4.0
> Jan 31, 2021

```
This update makes customizing the CSS (SCSS) and JavaScript easier:
- Added JavaScript source files in src/js
- Added SCSS source files in src/scss
- Dropped ui-learnplus-bootstrap private gitlab package dependency
- Updated most of package.json dependencies
- Improved browser support by upgrading to core-js v3.6.5
- Improved page preloader
- Improved charts usage and samples
```