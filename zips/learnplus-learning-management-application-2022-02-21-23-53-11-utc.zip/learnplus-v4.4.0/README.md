# LearnPlus Bootstrap
> Learning Management Application

LearnPlus is a beautifully crafted user interface for modern Learning web applications. LearnPlus includes examples for all the website pages possibly needed for a LMS application, covering the most important roles in any learning application: the student and the instructor.

## Documentation

[See Documentation Website](http://learnplus.frontendmatter.com/documentation.html)